# bagconvert

* Takes a bag file and converts it to a matlab file
* Needs to be inside of your ros workspace
* Matlab should be installed on your system